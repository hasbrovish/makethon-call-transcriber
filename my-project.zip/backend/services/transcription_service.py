import os
import logging
from datetime import datetime
import asyncio
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.sql import select
from models import CallRecord
from dotenv import load_dotenv
from rev_ai import apiclient
from rev_ai.models import JobStatus
import re
import openai
import json
import functools

# Load environment variables from .env file
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RevAIService:
    def __init__(self):
        self.api_key = os.getenv('REV_AI_API_KEY')
        if not self.api_key:
            raise ValueError("REV_AI_API_KEY environment variable is not set")
        
        self.client = apiclient.RevAiAPIClient(self.api_key)
        logger.info("RevAIService initialized successfully")

    async def submit_job(self, file_path: str) -> str:
        """Submit an audio file for transcription."""
        try:
            logger.info(f"Submitting job for file: {file_path}")
            # Run the synchronous client method in a thread pool
            loop = asyncio.get_event_loop()
            job = await loop.run_in_executor(
                None, 
                functools.partial(self.client.submit_job_local_file, file_path)
            )
            logger.info(f"Job submitted successfully with ID: {job.id}")
            return job.id
        except Exception as e:
            logger.error(f"Error submitting job: {str(e)}")
            raise

    async def check_job_status(self, job_id: str) -> str:
        """Check the status of a transcription job."""
        try:
            logger.info(f"Checking status for job: {job_id}")
            # Run the synchronous client method in a thread pool
            loop = asyncio.get_event_loop()
            job = await loop.run_in_executor(
                None,
                functools.partial(self.client.get_job_details, job_id)
            )
            logger.info(f"Job {job_id} status: {job.status}")
            return job.status
        except Exception as e:
            logger.error(f"Error checking job status: {str(e)}")
            raise

    async def get_transcript(self, job_id: str) -> dict:
        """Get the transcript for a completed job."""
        try:
            logger.info(f"Getting transcript for job: {job_id}")
            # Run the synchronous client method in a thread pool
            loop = asyncio.get_event_loop()
            transcript = await loop.run_in_executor(
                None,
                functools.partial(self.client.get_transcript_text, job_id)
            )
            logger.info(f"Successfully retrieved transcript for job: {job_id}")
            return {"text": transcript}
        except Exception as e:
            logger.error(f"Error getting transcript: {str(e)}")
            raise

    async def process_transcription(self, db: AsyncSession, call_id: int) -> None:
        """Process the transcription for a call record."""
        try:
            logger.info(f"Starting transcription process for call ID: {call_id}")
            
            # Get the call record
            result = await db.execute(
                select(CallRecord).where(CallRecord.id == call_id)
            )
            call = result.scalar_one_or_none()
            
            if not call:
                logger.error(f"Call record {call_id} not found")
                return
            
            if not call.audio_file_path:
                logger.error(f"No audio file path for call {call_id}")
                call.status = "failed"
                call.error_message = "No audio file path found"
                await db.commit()
                return
            
            logger.info(f"Found call record with audio file: {call.audio_file_path}")
            
            # Submit the job
            job_id = await self.submit_job(call.audio_file_path)
            
            # Update call record with job ID
            call.transcription_job_id = job_id
            call.status = "processing"
            await db.commit()
            logger.info(f"Updated call record with job ID: {job_id}")
            
            # Wait for job completion
            while True:
                status = await self.check_job_status(job_id)
                if status == JobStatus.TRANSCRIBED:
                    logger.info(f"Job {job_id} transcribed successfully")
                    break
                elif status == JobStatus.FAILED:
                    error_msg = f"Transcription job failed with status: {status}"
                    logger.error(error_msg)
                    call.status = "failed"
                    call.error_message = error_msg
                    await db.commit()
                    return
                elif status == JobStatus.IN_PROGRESS:
                    logger.info(f"Job {job_id} still in progress")
                    await asyncio.sleep(5)  # Wait 5 seconds before checking again
                else:
                    error_msg = f"Unexpected job status: {status}"
                    logger.error(error_msg)
                    call.status = "failed"
                    call.error_message = error_msg
                    await db.commit()
                    return
            
            # Get the transcript
            transcript_data = await self.get_transcript(job_id)
            raw_transcript = transcript_data["text"]
            
            # Parse transcript into chat structure
            chat = []
            for line in raw_transcript.strip().split('\n'):
                match = re.match(r'(Speaker \\d+)\\s+(\\d{2}:\\d{2}:\\d{2})\\s+(.*)', line)
                if match:
                    speaker, timestamp, message = match.groups()
                    role = "Agent" if speaker == "Speaker 0" else "Customer"
                    chat.append({
                        "role": role,
                        "timestamp": timestamp,
                        "message": message
                    })
            call.transcript = raw_transcript
            call.analysis = {"chat": chat}
            call.status = "completed"
            call.transcription_completed_at = datetime.utcnow()
            await db.commit()
            logger.info(f"Successfully updated call record {call_id} with transcript and chat structure")
            
        except Exception as e:
            logger.error(f"Error processing transcription for call {call_id}: {str(e)}")
            # Update call record with error status if it exists
            if call:
                call.status = "failed"
                call.error_message = str(e)
                await db.commit()
            raise

    def analyze_call_transcript_with_gpt(self, transcript: str) -> dict:
        """
        Analyze only agent (Speaker 0) messages in the transcript using OpenAI GPT API.
        Returns a dict with the required metrics and feedback.
        """
        system_prompt = (
            """
            You are a quality assurance evaluator for customer support calls.
            
            Score the following call transcript on a scale of 0–100 for each of these metrics:
            
            1. **Sentiment Score**: Rate the emotional tone of the agent (positive = higher).
            2. **SOP Adherence Score**: Evaluate if the agent followed all of these steps:
               - Professional greeting with company name
               - Asked for customer verification (account ID/phone)
               - Provided clear explanation or resolution
               - Asked if further help was needed
               - Polite closing (e.g., "Thanks for calling")
            3. **Empathy Score**: Rate how empathetic the agent sounded, e.g. using:
               "I understand", "Sorry", "Thanks for your patience", etc.
            4. **Talk Balance Score**: If one speaker dominates the conversation (>75%), reduce the score.
            5. **False Promises Detection**: Penalize if the agent said things like:
               "100% guaranteed", "This will never happen again", "Permanently fixed"
            
            Output this structured JSON object:
            {
              "sentiment_score": <0-100>,
              "sop_adherence_score": <0-100>,
              "empathy_score": <0-100>,
              "talk_balance_score": <0-100>,
              "false_promises_detected": <true/false>,
              "offending_statements": [list of quotes if any],
              "penalty_score": <negative int or 0>,
              "final_score": <0-100>,
              "feedback": "<1-2 lines of suggestions to the agent>"
            }
            """
        )
        # Only include agent (Speaker 0) messages
        agent_lines = []
        for line in transcript.strip().split('\n'):
            if line.strip().startswith("Speaker 0"):
                agent_lines.append(line)
        agent_transcript = '\n'.join(agent_lines)
        if not agent_transcript:
            return {"error": "No agent messages found in transcript."}
        try:
            openai.api_key = os.getenv("OPENAI_API_KEY")
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": agent_transcript}
                ],
                temperature=0.2,
                max_tokens=512
            )
            content = response["choices"][0]["message"]["content"]
            # Try to extract JSON from the response
            try:
                # Find the first and last curly braces to extract JSON
                start = content.find('{')
                end = content.rfind('}') + 1
                json_str = content[start:end]
                result = json.loads(json_str)
                return result
            except Exception as e:
                return {"error": "Failed to parse JSON from GPT response.", "raw": content, "exception": str(e)}
        except openai.error.OpenAIError as e:
            return {"error": f"OpenAI API error: {str(e)}"}
        except Exception as e:
            return {"error": f"Unexpected error: {str(e)}"} 