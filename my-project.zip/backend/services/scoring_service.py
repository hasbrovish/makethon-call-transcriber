import openai
import os
import json
# from openai import OpenAIError

class ScoringService:
    @staticmethod
    def analyze_call_transcript_with_gpt(transcript: str) -> dict:
        """
        Analyze only agent (Speaker 0) messages in the transcript using OpenAI GPT API (v1.x interface).
        Returns a dict with the required metrics and feedback.
        """
        system_prompt = (
            """
            You are a quality assurance evaluator for customer support calls.

            Your task is to score **only the agent's (Speaker 0)** part of a transcript.

            Each score must be between 0 and 100 using the rubric below.
            Use this scoring scale consistently across all metrics:

            - 90–100: Excellent — consistently meets expectations
            - 70–89: Good — mostly meets expectations with minor gaps
            - 50–69: Average — inconsistent or partially meets expectations
            - 30–49: Poor — major gaps in expected behavior
            - 0–29: Very poor — totally missing or inappropriate

            Evaluate the agent on:

            1. **Sentiment Score** — Tone of agent’s speech (friendly, positive tone = higher).
            2. **SOP Adherence Score** — Did the agent do all of these?
            - Professional greeting (with company name)
            - Customer verification
            - Clear resolution
            - Offer further assistance
            - Polite closing
            3. **Empathy Score** — Did agent show understanding, apologize when needed, or use empathetic phrases?
            4. **Talk Balance Score** — Deduct if agent dominates (>75% of words spoken).
            5. **False Promises Detection** — Did the agent say:
            - “100% guaranteed”, “permanent fix”, “never again”, etc.

            ⛔ If any such phrases are detected, return `false_promises_detected: true`, list those phrases, and apply a penalty between -5 and -20 depending on severity.

            ---

            Return a strict JSON format:

            {
            "sentiment": {"score": <0-100>, "feedback": "<1-2 lines>"},
            "sop_adherence": {"score": <0-100>, "feedback": "<1-2 lines>"},
            "empathy": {"score": <0-100>, "feedback": "<1-2 lines>"},
            "talk_balance": {"score": <0-100>, "feedback": "<1-2 lines>"},
            "false_promises_detected": <true|false>,
            "offending_statements": [list of false promises or empty list],
            "penalty_score": <int>,  # -5 to -20 if false promises, else 0
            "final_score": <0-100>,  # formula: weighted avg - penalty
            "overall_feedback": "<3-5 line summary for the agent>"
            }

            Rules:
            - Use the same rubric for every evaluation.
            - Avoid vague or random scoring.
            - Justify each score based on clear transcript evidence.
            """
        )
        # Only include agent (Speaker 0) messages
        agent_lines = []
        for line in transcript.strip().split('\n'):
            if line.strip().startswith("Speaker 0"):
                agent_lines.append(line)
        agent_transcript = '\n'.join(agent_lines)
        if not agent_transcript:
            return {"error": "No agent messages found in transcript."}
        try:
            client = openai.OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
            response = client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": agent_transcript}
                ],
                temperature=0.2,
                max_tokens=1024
            )
            content = response.choices[0].message.content
            # Try to extract JSON from the response
            try:
                # Find the first and last curly braces to extract JSON
                start = content.find('{')
                end = content.rfind('}') + 1
                json_str = content[start:end]
                result = json.loads(json_str)
                return result
            except Exception as e:
                return {"error": "Failed to parse JSON from GPT response.", "raw": content, "exception": str(e)}
        # except OpenAIError as e:
        #     return {"error": f"OpenAI API error: {str(e)}"}
        except Exception as e:
            return {"error": f"Unexpected error: {str(e)}"} 
