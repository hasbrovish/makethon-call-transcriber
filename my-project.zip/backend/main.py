from fastapi import FastAPI, UploadFile, File, Form, Depends, HTTPException, BackgroundTasks, Query
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
import os
import shutil
from datetime import datetime
import uuid
import requests
from typing import Optional, List
from models import CallRecord, Base, CallReport
from database import get_db, init_db, engine
from services.transcription_service import RevAIService
from services.scoring_service import ScoringService
from pydantic import BaseModel, EmailStr
import asyncio
import logging
import re

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create upload directory
UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

app = FastAPI()

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:4200"],  # Angular dev server
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize Rev.ai service
transcription_service = RevAIService()

# Initialize database on startup
@app.on_event("startup")
async def startup_event():
    await init_db()

class CallRecordResponse(BaseModel):
    id: int
    upload_date: datetime
    agent_email: str | None
    customer_email: str | None
    audio_file_path: str
    status: str
    transcription_job_id: str | None
    transcript: str | None
    transcription_completed_at: datetime | None
    error_message: str | None
    analysis: dict | None
    analysis_completed_at: datetime | None
    sentiment_score: float | None
    summary: str | None
    report: dict | None = None

    class Config:
        from_attributes = True

@app.post("/upload")
async def upload_call(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    agent_email: str | None = Form(None),
    customer_email: str | None = Form(None),
    db: AsyncSession = Depends(get_db)
):
    try:
        # Save the file
        file_path = os.path.join(UPLOAD_DIR, file.filename)
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        
        logger.info(f"Creating call record with agent_email: {agent_email}, customer_email: {customer_email}")
        
        # Create call record with all fields explicitly set
        call_record = CallRecord(
            agent_email=agent_email,
            customer_email=customer_email,
            audio_file_path=file_path,
            status="pending",
            upload_date=datetime.utcnow()
        )
        
        db.add(call_record)
        await db.commit()
        await db.refresh(call_record)
        
        logger.info(f"Created call record with ID: {call_record.id}, agent_email: {call_record.agent_email}")
        
        # Add transcription process to background tasks
        background_tasks.add_task(transcription_service.process_transcription, db, call_record.id)
        logger.info(f"Added transcription task to background for call ID: {call_record.id}")
        
        return call_record
    
    except Exception as e:
        logger.error(f"Error in upload_call: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/call/{call_id}", response_model=CallRecordResponse)
async def get_call(call_id: int, db: AsyncSession = Depends(get_db)):
    """Get a specific call record by ID, and include report if present"""
    result = await db.execute(
        select(CallRecord).where(CallRecord.id == call_id)
    )
    call_record = result.scalar_one_or_none()
    
    if not call_record:
        raise HTTPException(status_code=404, detail="Call record not found")
    
    logger.info(f"Retrieved call record: ID={call_record.id}, agent_email={call_record.agent_email}, customer_email={call_record.customer_email}")
    
    # Parse transcript into chat structure on the fly
    chat = []
    if call_record.transcript:
        for line in call_record.transcript.strip().split('\n'):
            match = re.match(r'(Speaker \d+)\s+(\d{2}:\d{2}:\d{2})\s+(.*)', line)
            if match:
                speaker, timestamp, message = match.groups()
                role = "Agent" if speaker == "Speaker 0" else "Customer"
                chat.append({
                    "role": role,
                    "timestamp": timestamp,
                    "message": message
                })
    
    # Fetch report if exists
    report_result = await db.execute(select(CallReport).where(CallReport.call_id == call_id))
    report = report_result.scalar_one_or_none()
    
    # Create response dictionary
    response_dict = {
        "id": call_record.id,
        "upload_date": call_record.upload_date,
        "agent_email": call_record.agent_email,
        "customer_email": call_record.customer_email,
        "audio_file_path": call_record.audio_file_path,
        "status": call_record.status,
        "transcription_job_id": call_record.transcription_job_id,
        "transcript": call_record.transcript,
        "transcription_completed_at": call_record.transcription_completed_at,
        "error_message": call_record.error_message,
        "analysis": {"chat": chat},
        "analysis_completed_at": call_record.analysis_completed_at,
        "sentiment_score": call_record.sentiment_score,
        "summary": call_record.summary,
    }
    
    # Add report if it exists
    if report:
        response_dict["report"] = {
            "id": report.id,
            "call_id": report.call_id,
            "status": report.status,
            "created_at": str(report.created_at) if report.created_at else None,
            "completed_at": str(report.completed_at) if report.completed_at else None,
            "error_message": report.error_message,
            "report": report.report,
        }
    
    return response_dict

@app.get("/call/{call_id}/status")
def get_call_status(call_id: int, db: Session = Depends(get_db)):
    call = db.query(models.CallRecord).filter(models.CallRecord.id == call_id).first()
    if call is None:
        raise HTTPException(status_code=404, detail="Call not found")
    return {"status": call.status}

@app.post("/api/calls/", response_model=CallRecordResponse)
async def upload_call(
    file: UploadFile = File(...),
    agent_email: str | None = None,
    customer_email: str | None = None,
    db: AsyncSession = Depends(get_db)
):
    # Save the uploaded file
    file_path = f"uploads/{file.filename}"
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    # Create call record
    call_record = CallRecord(
        agent_email=agent_email,
        customer_email=customer_email,
        audio_file_path=file_path,
        transcription_status="pending"
    )
    db.add(call_record)
    await db.commit()
    await db.refresh(call_record)

    # Start transcription process in background
    asyncio.create_task(transcription_service.process_transcription(db, call_record.id))

    return call_record

@app.get("/api/calls/", response_model=List[CallRecordResponse])
async def list_calls(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(CallRecord).order_by(CallRecord.upload_date.desc()))
    return result.scalars().all()

@app.post("/upload-sync")
async def upload_call_sync(
    file: UploadFile = File(...),
    agent_email: str | None = Form(None),
    customer_email: str | None = Form(None),
    db: AsyncSession = Depends(get_db)
):
    try:
        # Save the file
        file_path = os.path.join(UPLOAD_DIR, file.filename)
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        
        logger.info(f"Creating call record with agent_email: {agent_email}, customer_email: {customer_email}")
        
        # Create call record with all fields explicitly set
        call_record = CallRecord(
            agent_email=agent_email,
            customer_email=customer_email,
            audio_file_path=file_path,
            status="pending",
            upload_date=datetime.utcnow()
        )
        
        db.add(call_record)
        await db.commit()
        await db.refresh(call_record)
        
        logger.info(f"Created call record with ID: {call_record.id}, agent_email: {call_record.agent_email}")
        
        # Process transcription synchronously
        try:
            await transcription_service.process_transcription(db, call_record.id)
            logger.info(f"Transcription completed for call ID: {call_record.id}")
        except Exception as e:
            logger.error(f"Error in transcription: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Transcription failed: {str(e)}")
        
        # Get the updated record
        result = await db.execute(
            select(CallRecord).where(CallRecord.id == call_record.id)
        )
        updated_record = result.scalar_one_or_none()
        
        return updated_record
    
    except Exception as e:
        logger.error(f"Error in upload_call_sync: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/generate_report/{call_id}")
async def generate_report(call_id: int, revaluate: bool = Query(False), db: AsyncSession = Depends(get_db)):
    # Check if report already exists
    result = await db.execute(select(CallReport).where(CallReport.call_id == call_id))
    report = result.scalar_one_or_none()
    if report and not revaluate:
        return report
    # Get the call record
    result = await db.execute(select(CallRecord).where(CallRecord.id == call_id))
    call_record = result.scalar_one_or_none()
    if not call_record or not call_record.transcript:
        raise HTTPException(status_code=404, detail="Call record or transcript not found")
    if report and revaluate:
        # Set to pending and clear error
        report.status = "pending"
        report.error_message = None
        report.completed_at = None
        await db.commit()
        await db.refresh(report)
        new_report = report
    else:
        # Create new report with status pending
        new_report = CallReport(
            call_id=call_id,
            status="pending",
            created_at=datetime.utcnow()
        )
        db.add(new_report)
        await db.commit()
        await db.refresh(new_report)
    try:
        # Run scoring
        scoring = ScoringService.analyze_call_transcript_with_gpt(call_record.transcript)
        new_report.report = scoring
        new_report.status = "completed"
        new_report.completed_at = datetime.utcnow()
        await db.commit()
        await db.refresh(new_report)
    except Exception as e:
        new_report.status = "failed"
        new_report.error_message = str(e)
        await db.commit()
        await db.refresh(new_report)
        raise HTTPException(status_code=500, detail=f"Scoring failed: {str(e)}")
    return new_report

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000) 
