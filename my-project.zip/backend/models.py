from sqlalchemy import Column, Integer, String, DateTime, Text, JSON, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func
from datetime import datetime

Base = declarative_base()

class CallRecord(Base):
    __tablename__ = "call_records"

    id = Column(Integer, primary_key=True, index=True)
    agent_email = Column(String, index=True)
    customer_email = Column(String, index=True)
    audio_file_path = Column(String)
    upload_date = Column(DateTime, default=datetime.utcnow)
    
    # Transcription related fields
    status = Column(String, default="pending")  # pending, processing, completed, failed
    transcription_job_id = Column(String, nullable=True)
    transcript = Column(Text, nullable=True)
    transcription_completed_at = Column(DateTime, nullable=True)
    error_message = Column(Text, nullable=True)
    
    # Analysis related fields
    analysis = Column(JSON, nullable=True)
    analysis_completed_at = Column(DateTime, nullable=True)
    sentiment_score = Column(Float, nullable=True)
    summary = Column(Text, nullable=True)

class CallReport(Base):
    __tablename__ = "call_reports"

    id = Column(Integer, primary_key=True, index=True)
    call_id = Column(Integer, index=True, unique=True)
    status = Column(String, default="pending")  # pending, completed, failed
    report = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)
    error_message = Column(Text, nullable=True) 