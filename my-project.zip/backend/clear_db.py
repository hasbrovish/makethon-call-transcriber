import asyncio
from database import engine
from models import Base

async def clear_database():
    """Drop all tables and recreate them."""
    async with engine.begin() as conn:
        # Drop all tables
        await conn.run_sync(Base.metadata.drop_all)
        print("All tables dropped successfully")
        
        # Recreate all tables
        await conn.run_sync(Base.metadata.create_all)
        print("All tables recreated successfully")

if __name__ == "__main__":
    asyncio.run(clear_database()) 