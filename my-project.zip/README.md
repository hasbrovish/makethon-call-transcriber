# Call Transcript Analyzer

A real-time call analysis system that leverages LLMs to analyze customer support conversations and provide performance metrics.

## Features

- Audio transcription using Whisper
- Real-time transcript analysis
- Performance metrics:
  - Sentiment Analysis
  - SOP Adherence
  - Empathy Detection
  - Talk Ratio Analysis
  - False Promises Detection
  - Abusive Language Detection
- Angular-based frontend dashboard
- RESTful API endpoints

## Project Structure

```
call_transcriver/
├── backend/
│   ├── app/
│   │   ├── api/
│   │   ├── core/
│   │   ├── models/
│   │   └── services/
│   ├── requirements.txt
│   └── main.py
├── frontend/
│   ├── src/
│   │   ├── app/
│   │   ├── assets/
│   │   └── environments/
│   └── package.json
└── README.md
```

## Setup Instructions

### Backend Setup

1. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. Install dependencies:
```bash
cd backend
pip install -r requirements.txt
```

3. Run the backend server:
```bash
uvicorn main:app --reload
```

### Frontend Setup

1. Install Node.js dependencies:
```bash
cd frontend
npm install
```

2. Run the development server:
```bash
ng serve
```

## API Endpoints

- `POST /upload_audio`: Upload audio file for transcription
- `POST /analyze_transcript`: Analyze transcript and return scoring report
- `GET /sop_list`: Fetch configurable SOPs

## Technologies Used

- Backend:
  - FastAPI
  - OpenAI Whisper
  - HuggingFace Transformers
  - Sentence Transformers
  - PyTorch

- Frontend:
  - Angular
  - TypeScript
  - Bootstrap
  - Chart.js

## License

MIT
