import { Component } from '@angular/core';

@Component({
  selector: 'app-transcript-display',
  imports: [],
  template: `
    <p>
      transcript-display works!
    </p>
  `,
  styles: ``
})
export class TranscriptDisplay {

}
