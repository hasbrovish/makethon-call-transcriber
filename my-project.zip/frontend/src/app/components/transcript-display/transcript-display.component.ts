import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranscriptService, CallRecord } from '../../services/transcript.service';

@Component({
  selector: 'app-transcript-display',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="transcript-container">
      <div *ngIf="loading" class="loading">Loading transcript...</div>
      <div *ngIf="error" class="error">{{ error }}</div>
      <div *ngIf="!loading && !error && transcript" class="transcript">
        <h3>Transcript</h3>
        <p>{{ transcript }}</p>
      </div>
    </div>
  `,
  styles: [`
    .transcript-container {
      margin: 20px 0;
      padding: 20px;
      border: 1px solid #ddd;
      border-radius: 4px;
    }
    .loading {
      color: #666;
      text-align: center;
    }
    .error {
      color: red;
      text-align: center;
    }
    .transcript {
      white-space: pre-wrap;
    }
    h3 {
      margin-bottom: 15px;
    }
  `]
})
export class TranscriptDisplayComponent implements OnInit {
  @Input() audioId!: string;
  transcript: string = '';
  loading: boolean = false;
  error: string = '';

  constructor(private transcriptService: TranscriptService) {}

  ngOnInit(): void {
    this.loadTranscript();
  }

  loadTranscript(): void {
    this.loading = true;
    this.error = '';
    
    this.transcriptService.getCallStatus(parseInt(this.audioId)).subscribe({
      next: (data: CallRecord) => {
        this.transcript = data.transcript || '';
        this.loading = false;
      },
      error: (err: Error) => {
        console.error('Error loading transcript:', err);
        this.error = 'Failed to load transcript';
        this.loading = false;
      }
    });
  }
}
