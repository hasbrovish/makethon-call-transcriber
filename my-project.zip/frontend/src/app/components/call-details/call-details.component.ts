import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { TranscriptService, CallRecord, CallReport } from '../../services/transcript.service';

@Component({
  selector: 'app-call-details',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="call-details-2panel">
      <!-- Left Panel: Call Details -->
      <div class="left-panel">
        <div class="call-details-card">
          <h2>Call Details</h2>
          <div class="details-grid">
            <div class="detail-label">Agent Email:</div>
            <div class="detail-value">{{ call?.agent_email }}</div>
            <div class="detail-label">Customer Email:</div>
            <div class="detail-value">{{ call?.customer_email }}</div>
            <div class="detail-label">Status:</div>
            <div class="detail-value status-{{ call?.status }}">{{ call?.status | titlecase }}</div>
            <div class="detail-label">Created At:</div>
            <div class="detail-value">{{ call?.upload_date | date:'medium' }}</div>
          </div>
        </div>
        <!-- Chat View -->
        <div *ngIf="call?.analysis?.chat" class="chat-section">
          <h3>Chat View</h3>
          <div class="chat-container">
            <div *ngFor="let msg of call?.analysis?.chat" [ngClass]="{'agent-msg': msg.role === 'Agent', 'customer-msg': msg.role === 'Customer'}" class="chat-message">
              <div class="chat-meta">
                <span class="chat-role">{{ msg.role }}</span>
                <span class="chat-time">{{ msg.timestamp }}</span>
              </div>
              <div class="chat-text">{{ msg.message }}</div>
            </div>
          </div>
        </div>
        <!-- Raw Transcript -->
        <div *ngIf="call?.transcript" class="transcript-section">
          <h3>Raw Transcript</h3>
          <div class="transcript">{{ call?.transcript }}</div>
        </div>
      </div>
      <!-- Right Panel: Report -->
      <div class="right-panel">
        <button *ngIf="!call?.report" (click)="onGenerateReport()" [disabled]="reportLoading" class="generate-report-btn">
          {{ reportLoading ? 'Generating Report...' : 'Generate Report' }}
        </button>
        <div *ngIf="reportError" class="error">{{ reportError }}</div>
        <div *ngIf="call?.report">
          <div *ngIf="getReportStatus() === 'pending'" class="pending-report">
            <div class="spinner"></div>
            <p>Report is being generated...</p>
          </div>
          <div *ngIf="getReportStatus() === 'completed' && hasReportData()">
            <div class="score-circle" [ngClass]="getScoreClass(getFinalScore())">
              <span class="score-value">{{ getFinalScore() }}</span>
              <span class="score-label">/ 100</span>
            </div>
            <div class="score-tiles">
              <div class="score-tile" *ngFor="let metric of detailedMetrics">
                <div class="tile-label">{{ metric.label }}</div>
                <div class="tile-score">{{ getDetailedMetricScore(metric.key) }} / 100</div>
                <div class="tile-feedback">{{ getDetailedMetricFeedback(metric.key) }}</div>
              </div>
            </div>
            <div class="feedback-box">
              <strong>Overall Feedback:</strong>
              <div>{{ getOverallFeedback() }}</div>
            </div>
            <div *ngIf="getOffendingStatements().length > 0">
              <strong>Offending Statements:</strong>
              <ul>
                <li *ngFor="let stmt of getOffendingStatements()">{{ stmt }}</li>
              </ul>
            </div>
          </div>
          <button (click)="onRegenerateReport()" [disabled]="reportLoading" class="regenerate-report-btn">
            {{ reportLoading ? 'Regenerating...' : 'Regenerate Report' }}
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [
    `
    .call-details-2panel {
      display: flex;
      gap: 32px;
      margin: 0 auto;
      max-width: 1200px;
    }
    .left-panel, .right-panel {
      background: #fff;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.07);
      padding: 24px;
      flex: 1 1 0;
      min-width: 0;
    }
    .left-panel {
      max-width: 55%;
      flex-basis: 55%;
    }
    .right-panel {
      max-width: 45%;
      flex-basis: 45%;
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    @media (max-width: 900px) {
      .call-details-2panel {
        flex-direction: column;
      }
      .left-panel, .right-panel {
        max-width: 100%;
        flex-basis: 100%;
        margin-bottom: 24px;
      }
    }
    .generate-report-btn {
      margin: 20px 0 10px 0;
      padding: 10px 20px;
      background: #1976d2;
      color: #fff;
      border: none;
      border-radius: 4px;
      font-size: 1em;
      cursor: pointer;
    }
    .generate-report-btn:disabled {
      background: #ccc;
      cursor: not-allowed;
    }
    .score-circle {
      width: 110px;
      height: 110px;
      border-radius: 50%;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      font-size: 2.2em;
      font-weight: bold;
      margin: 20px auto;
      border: 6px solid #28a745;
      background: #eafaf1;
    }
    .score-red {
      border-color: #dc3545 !important;
      background: #fdeaea !important;
      color: #dc3545 !important;
    }
    .score-green {
      border-color: #28a745 !important;
      background: #eafaf1 !important;
      color: #28a745 !important;
    }
    .score-label {
      font-size: 0.5em;
      color: #888;
    }
    .score-tiles {
      display: flex;
      gap: 16px;
      margin: 20px 0;
      flex-wrap: wrap;
      justify-content: center;
    }
    .score-tile {
      min-width: 120px;
      padding: 16px;
      border-radius: 8px;
      background: #f8f9fa;
      text-align: center;
      font-size: 1.1em;
      box-shadow: 0 1px 3px rgba(0,0,0,0.04);
    }
    .score-tile.score-red {
      background: #fdeaea;
      color: #dc3545;
    }
    .score-tile.score-green {
      background: #eafaf1;
      color: #28a745;
    }
    .tile-label {
      font-weight: bold;
      margin-bottom: 6px;
    }
    .tile-score {
      font-size: 1.3em;
    }
    .tile-feedback {
      font-size: 0.95em;
      color: #555;
      margin-top: 6px;
    }
    .feedback-box {
      background: #fffbe6;
      border-left: 5px solid #ffc107;
      padding: 16px;
      margin: 20px 0;
      border-radius: 6px;
      font-size: 1.1em;
    }
    .pending-report {
      text-align: center;
      color: #888;
      margin: 30px 0;
    }
    pre {
      background: #f8f9fa;
      padding: 10px;
      border-radius: 4px;
      font-size: 0.95em;
      margin-top: 10px;
    }
    /* Existing chat and transcript styles remain unchanged */
    .chat-section {
      margin-top: 30px;
      padding-top: 20px;
      border-top: 1px solid #dee2e6;
    }
    .chat-container {
      display: flex;
      flex-direction: column;
      gap: 12px;
      margin-top: 10px;
    }
    .chat-message {
      padding: 10px 15px;
      border-radius: 8px;
      max-width: 70%;
      word-break: break-word;
      background: #f1f3f4;
      box-shadow: 0 1px 2px rgba(0,0,0,0.03);
    }
    .agent-msg {
      align-self: flex-start;
      background: #e3f2fd;
      border-left: 4px solid #1976d2;
    }
    .customer-msg {
      align-self: flex-end;
      background: #fff3e0;
      border-right: 4px solid #ff9800;
    }
    .chat-meta {
      font-size: 0.85em;
      color: #888;
      margin-bottom: 2px;
      display: flex;
      justify-content: space-between;
    }
    .chat-role {
      font-weight: bold;
    }
    .chat-time {
      font-style: italic;
    }
    .chat-text {
      font-size: 1.05em;
      color: #222;
    }
    .transcript-section {
      margin-top: 30px;
      padding-top: 20px;
      border-top: 1px solid #dee2e6;
    }
    .transcript {
      white-space: pre-wrap;
      background: #f8f9fa;
      padding: 15px;
      border-radius: 4px;
      margin-top: 10px;
    }
    .call-details-card {
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 4px 16px rgba(0,0,0,0.08);
      padding: 32px 40px;
      max-width: 500px;
      margin: 0 auto 32px auto;
    }
    .call-details-card h2 {
      margin-bottom: 24px;
      font-size: 2em;
      font-weight: 700;
      color: #222;
    }
    .details-grid {
      display: grid;
      grid-template-columns: 140px 1fr;
      row-gap: 18px;
      column-gap: 16px;
    }
    .detail-label {
      font-weight: 600;
      color: #555;
      text-align: right;
    }
    .detail-value {
      font-weight: 400;
      color: #222;
      word-break: break-all;
    }
    .status-completed {
      color: #28a745;
      font-weight: 700;
    }
    .status-pending {
      color: #ffc107;
      font-weight: 700;
    }
    .status-failed {
      color: #dc3545;
      font-weight: 700;
    }
    .regenerate-report-btn {
      margin: 24px 0 0 0;
      padding: 10px 20px;
      background: #ff9800;
      color: #fff;
      border: none;
      border-radius: 4px;
      font-size: 1em;
      cursor: pointer;
    }
    .regenerate-report-btn:disabled {
      background: #ccc;
      cursor: not-allowed;
    }
    `
  ]
})
export class CallDetailsComponent implements OnInit {
  call: CallRecord | null = null;
  loading: boolean = false;
  error: string = '';
  reportLoading: boolean = false;
  reportError: string = '';

  detailedMetrics = [
    { key: 'sentiment', label: 'Sentiment' },
    { key: 'sop_adherence', label: 'SOP Adherence' },
    { key: 'empathy', label: 'Empathy' },
    { key: 'talk_balance', label: 'Talk Balance' }
  ];

  constructor(
    private route: ActivatedRoute,
    private transcriptService: TranscriptService
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      if (params['id']) {
        this.loadCallDetails(params['id']);
      }
    });
  }

  loadCallDetails(id: string): void {
    this.loading = true;
    this.error = '';
    this.transcriptService.getCallStatus(parseInt(id)).subscribe({
      next: (data: CallRecord) => {
        this.call = data;
        this.loading = false;
      },
      error: (err: Error) => {
        this.error = 'Failed to load call details';
        this.loading = false;
        console.error('Error loading call details:', err);
      }
    });
  }

  retryLoading(): void {
    if (this.call?.id) {
      this.loadCallDetails(this.call.id.toString());
    }
  }

  onGenerateReport(): void {
    if (!this.call?.id) return;
    
    this.reportLoading = true;
    this.reportError = '';
    
    this.transcriptService.generateReport(this.call.id).subscribe({
      next: (report: CallReport) => {
        if (this.call) {
          this.call.report = report;
        }
        this.reportLoading = false;
      },
      error: (err: Error) => {
        this.reportError = 'Failed to generate report';
        this.reportLoading = false;
        console.error('Error generating report:', err);
      }
    });
  }

  onRegenerateReport(): void {
    if (!this.call?.id) return;
    this.reportLoading = true;
    this.reportError = '';
    // Set report status to pending in UI
    if (this.call.report) {
      this.call.report.status = 'pending';
    }
    this.transcriptService.regenerateReport(this.call.id).subscribe({
      next: (report: CallReport) => {
        if (this.call) {
          this.call.report = report;
        }
        this.reportLoading = false;
      },
      error: (err: Error) => {
        this.reportError = 'Failed to regenerate report';
        this.reportLoading = false;
        console.error('Error regenerating report:', err);
      }
    });
  }

  getScoreClass(score: number): string {
    if (score >= 80) return 'score-green';
    if (score < 60) return 'score-red';
    return '';
  }

  getReportStatus(): string {
    return this.call?.report?.status || '';
  }

  hasReportData(): boolean {
    return !!this.call?.report?.report;
  }

  getFinalScore(): number {
    return this.call?.report?.report?.final_score || 0;
  }

  getDetailedMetricScore(key: string): number {
    return this.call?.report?.report?.[key]?.score ?? 0;
  }

  getDetailedMetricFeedback(key: string): string {
    return this.call?.report?.report?.[key]?.feedback ?? '';
  }

  getOverallFeedback(): string {
    return this.call?.report?.report?.overall_feedback ?? '';
  }

  getOffendingStatements(): string[] {
    return this.call?.report?.report?.offending_statements || [];
  }
} 