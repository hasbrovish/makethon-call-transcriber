import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranscriptService } from '../../services/transcript.service';

@Component({
  selector: 'app-analysis-results',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="analysis-container">
      <h2>Call Analysis</h2>
      
      <div class="loading" *ngIf="loading">Analyzing call...</div>
      
      <div class="analysis-content" *ngIf="analysis">
        <!-- Sentiment Analysis -->
        <div class="analysis-section">
          <h3>Overall Sentiment</h3>
          <div class="sentiment-score" [ngClass]="getSentimentClass()">
            {{analysis.sentiment_score | number:'1.0-2'}}
          </div>
          <p class="sentiment-label">{{getSentimentLabel()}}</p>
        </div>

        <!-- Key Topics -->
        <div class="analysis-section">
          <h3>Key Topics</h3>
          <div class="topics-list">
            <div class="topic-item" *ngFor="let topic of analysis.topics">
              <span class="topic-name">{{topic.name}}</span>
              <span class="topic-mentions">({{topic.mentions}} mentions)</span>
            </div>
          </div>
        </div>

        <!-- Action Items -->
        <div class="analysis-section">
          <h3>Action Items</h3>
          <ul class="action-items">
            <li *ngFor="let item of analysis.action_items">
              {{item}}
            </li>
          </ul>
        </div>

        <!-- Call Summary -->
        <div class="analysis-section">
          <h3>Call Summary</h3>
          <p class="summary-text">{{analysis.summary}}</p>
        </div>
      </div>

      <div class="error-message" *ngIf="error">
        {{error}}
      </div>
    </div>
  `,
  styles: [`
    .analysis-container {
      padding: 20px;
      background: white;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .analysis-section {
      margin-bottom: 30px;
    }
    .sentiment-score {
      font-size: 2.5em;
      font-weight: bold;
      text-align: center;
      margin: 20px 0;
    }
    .sentiment-positive {
      color: #28a745;
    }
    .sentiment-neutral {
      color: #ffc107;
    }
    .sentiment-negative {
      color: #dc3545;
    }
    .sentiment-label {
      text-align: center;
      color: #666;
      font-style: italic;
    }
    .topics-list {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
    }
    .topic-item {
      background: #f8f9fa;
      padding: 8px 15px;
      border-radius: 20px;
      font-size: 0.9em;
    }
    .topic-mentions {
      color: #666;
      font-size: 0.8em;
      margin-left: 5px;
    }
    .action-items {
      list-style-type: none;
      padding: 0;
    }
    .action-items li {
      padding: 8px 0;
      border-bottom: 1px solid #eee;
    }
    .action-items li:last-child {
      border-bottom: none;
    }
    .summary-text {
      line-height: 1.6;
      color: #333;
    }
    .loading {
      color: #666;
      font-style: italic;
      text-align: center;
      padding: 20px;
    }
    .error-message {
      color: #dc3545;
      padding: 10px;
      background: #f8d7da;
      border-radius: 4px;
      margin-top: 10px;
    }
  `]
})
export class AnalysisResultsComponent implements OnInit {
  @Input() audioId: string = '';
  analysis: any = null;
  loading: boolean = false;
  error: string = '';

  constructor(private transcriptService: TranscriptService) {}

  ngOnInit() {
    if (this.audioId) {
      this.loadAnalysis();
    }
  }

  ngOnChanges() {
    if (this.audioId) {
      this.loadAnalysis();
    }
  }

  private loadAnalysis() {
    this.loading = true;
    this.error = '';
    
    this.transcriptService.getAnalysis(this.audioId).subscribe({
      next: (data) => {
        this.analysis = data;
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Error loading analysis. Please try again.';
        this.loading = false;
        console.error('Error loading analysis:', err);
      }
    });
  }

  getSentimentClass(): string {
    if (!this.analysis) return '';
    const score = this.analysis.sentiment_score;
    if (score > 0.3) return 'sentiment-positive';
    if (score < -0.3) return 'sentiment-negative';
    return 'sentiment-neutral';
  }

  getSentimentLabel(): string {
    if (!this.analysis) return '';
    const score = this.analysis.sentiment_score;
    if (score > 0.3) return 'Positive';
    if (score < -0.3) return 'Negative';
    return 'Neutral';
  }
} 