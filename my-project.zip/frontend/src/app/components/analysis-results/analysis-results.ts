import { Component } from '@angular/core';

@Component({
  selector: 'app-analysis-results',
  imports: [],
  template: `
    <p>
      analysis-results works!
    </p>
  `,
  styles: ``
})
export class AnalysisResults {

}
