import { Component, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { TranscriptService } from '../../services/transcript.service';

@Component({
  selector: 'app-file-upload',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="upload-container">
      <form (ngSubmit)="uploadFile()" #uploadForm="ngForm">
        <div class="form-group">
          <label for="agentEmail">Agent Email:</label>
          <input 
            type="email" 
            id="agentEmail" 
            name="agentEmail"
            [(ngModel)]="agentEmail" 
            required
            #agentEmailInput="ngModel">
          <div *ngIf="agentEmailInput.invalid && agentEmailInput.touched" class="error">
            Please enter a valid agent email
          </div>
        </div>

        <div class="form-group">
          <label for="customerEmail">Customer Email:</label>
          <input 
            type="email" 
            id="customerEmail" 
            name="customerEmail"
            [(ngModel)]="customerEmail" 
            required
            #customerEmailInput="ngModel">
          <div *ngIf="customerEmailInput.invalid && customerEmailInput.touched" class="error">
            Please enter a valid customer email
          </div>
        </div>

        <div class="file-input">
          <input 
            type="file" 
            (change)="onFileSelected($event)" 
            accept="audio/*"
            required>
          <div *ngIf="selectedFile" class="selected-file">
            Selected file: {{ selectedFile.name }}
          </div>
        </div>

        <button 
          type="submit" 
          [disabled]="!isFormValid() || uploadStatus === 'uploading'">
          {{ uploadStatus === 'uploading' ? 'Uploading...' : 'Upload' }}
        </button>

        <div *ngIf="error" class="error">{{ error }}</div>
        <div *ngIf="uploadStatus === 'success'" class="success">File uploaded successfully!</div>
      </form>
    </div>
  `,
  styles: [`
    .upload-container {
      margin: 20px 0;
      padding: 20px;
      border: 1px solid #ddd;
      border-radius: 4px;
    }
    .form-group {
      margin-bottom: 15px;
    }
    label {
      display: block;
      margin-bottom: 5px;
    }
    input[type="email"] {
      width: 100%;
      padding: 8px;
      border: 1px solid #ddd;
      border-radius: 4px;
    }
    .file-input {
      margin: 20px 0;
    }
    .selected-file {
      margin-top: 10px;
      padding: 8px;
      background: #f8f9fa;
      border-radius: 4px;
    }
    button {
      width: 100%;
      padding: 10px;
      background-color: #007bff;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
    }
    button:disabled {
      background-color: #ccc;
      cursor: not-allowed;
    }
    .error {
      color: #dc3545;
      margin-top: 10px;
      font-size: 14px;
    }
    .success {
      color: #28a745;
      margin-top: 10px;
      font-size: 14px;
    }
  `]
})
export class FileUploadComponent {
  @Output() fileUploaded = new EventEmitter<string>();
  selectedFile: File | null = null;
  agentEmail: string = '';
  customerEmail: string = '';
  error: string = '';
  uploadStatus: 'idle' | 'uploading' | 'success' | 'error' = 'idle';

  constructor(
    private transcriptService: TranscriptService,
    private router: Router
  ) {}

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedFile = input.files[0];
      this.error = '';
    }
  }

  isFormValid(): boolean {
    return this.selectedFile !== null && 
           this.agentEmail !== '' && 
           this.customerEmail !== '' &&
           this.validateEmail(this.agentEmail) &&
           this.validateEmail(this.customerEmail);
  }

  validateEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  uploadFile(): void {
    if (!this.isFormValid()) {
      return;
    }

    const formData = new FormData();
    formData.append('file', this.selectedFile!);
    formData.append('agent_email', this.agentEmail);
    formData.append('customer_email', this.customerEmail);

    this.uploadStatus = 'uploading';
    this.error = '';

    this.transcriptService.uploadAudio(formData).subscribe({
      next: (response) => {
        this.uploadStatus = 'success';
        this.fileUploaded.emit(response.id.toString());
        // Navigate to call details page
        this.router.navigate(['/call', response.id]);
      },
      error: (error) => {
        console.error('Upload failed:', error);
        this.error = 'Upload failed. Please try again.';
        this.uploadStatus = 'error';
      }
    });
  }
} 