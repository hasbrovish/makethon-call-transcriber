import { Component } from '@angular/core';

@Component({
  selector: 'app-file-upload',
  imports: [],
  template: `
    <p>
      file-upload works!
    </p>
  `,
  styles: ``
})
export class FileUpload {

}
