import { Component } from '@angular/core';

@Component({
  selector: 'app-header',
  standalone: true,
  template: `
    <header class="main-header">
      <div class="logo">CallTranscriber</div>
      <nav>
        <a routerLink="/home" routerLinkActive="active">Home</a>
        <a routerLink="/calls" routerLinkActive="active">Calls</a>
        <!-- Add more links as needed -->
      </nav>
    </header>
  `,
  styles: [
    `
    .main-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      background: #222;
      color: #fff;
      padding: 0 32px;
      height: 64px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.07);
    }
    .logo {
      font-size: 1.5em;
      font-weight: 700;
      letter-spacing: 1px;
    }
    nav a {
      color: #fff;
      text-decoration: none;
      margin-left: 32px;
      font-size: 1.1em;
      font-weight: 500;
      transition: color 0.2s;
    }
    nav a.active, nav a:hover {
      color: #4fc3f7;
    }
    @media (max-width: 600px) {
      .main-header {
        flex-direction: column;
        height: auto;
        padding: 16px;
      }
      nav a {
        margin-left: 0;
        margin-right: 16px;
      }
    }
    `
  ]
})
export class HeaderComponent {} 