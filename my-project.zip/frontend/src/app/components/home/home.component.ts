import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FileUploadComponent } from '../file-upload/file-upload.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, FileUploadComponent],
  template: `
    <div class="home-container">
      <h1>Call Transcript Analyzer</h1>
      <app-file-upload (fileUploaded)="onFileUploaded($event)"></app-file-upload>
    </div>
  `,
  styles: [`
    .home-container {
      max-width: 800px;
      margin: 0 auto;
      padding: 20px;
    }
    h1 {
      text-align: center;
      margin-bottom: 30px;
    }
  `]
})
export class HomeComponent {
  constructor(private router: Router) {}

  onFileUploaded(id: string): void {
    this.router.navigate(['/call', id]);
  }
} 