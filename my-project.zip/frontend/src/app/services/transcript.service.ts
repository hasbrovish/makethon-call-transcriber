import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface CallReport {
  id: number;
  call_id: number;
  status: string;
  created_at?: string;
  completed_at?: string;
  error_message?: string;
  report?: any;
}

export interface CallRecord {
  id: number;
  agent_email: string;
  customer_email: string;
  audio_file_path: string;
  status: string;
  transcript?: string;
  transcript_completed_at?: string;
  error_message?: string;
  analysis?: any;
  created_at?: string;
  upload_date?: string;
  report?: CallReport | null;
}

@Injectable({
  providedIn: 'root'
})
export class TranscriptService {
  private apiUrl = 'http://localhost:8000';

  constructor(private http: HttpClient) {}

  uploadAudio(formData: FormData): Observable<CallRecord> {
    return this.http.post<CallRecord>(`${this.apiUrl}/upload`, formData);
  }

  getCallStatus(callId: number): Observable<CallRecord> {
    return this.http.get<CallRecord>(`${this.apiUrl}/call/${callId}`);
  }

  getAnalysis(audioId: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/analyze/${audioId}`);
  }

  generateReport(callId: number): Observable<any> {
    return this.http.post(`${this.apiUrl}/generate_report/${callId}`, {});
  }

  regenerateReport(callId: number): Observable<any> {
    return this.http.post(`${this.apiUrl}/generate_report/${callId}?revaluate=true`, {});
  }
} 