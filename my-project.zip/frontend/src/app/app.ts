import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { FileUploadComponent } from './components/file-upload/file-upload.component';
import { TranscriptDisplayComponent } from './components/transcript-display/transcript-display.component';
import { AnalysisResultsComponent } from './components/analysis-results/analysis-results.component';
import { HeaderComponent } from './components/header.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    RouterOutlet,
    FileUploadComponent,
    TranscriptDisplayComponent,
    AnalysisResultsComponent,
    HeaderComponent
  ],
  template: `
    <app-header></app-header>
    <div class="app-container">
      <main class="app-content">
        <div class="upload-section" *ngIf="!currentAudioId">
          <app-file-upload (fileUploaded)="onFileUploaded($event)"></app-file-upload>
        </div>

        <div class="results-section" *ngIf="currentAudioId">
          <div class="transcript-section">
            <app-transcript-display [audioId]="currentAudioId"></app-transcript-display>
          </div>
          
          <div class="analysis-section">
            <app-analysis-results [audioId]="currentAudioId"></app-analysis-results>
          </div>
        </div>
      </main>
    </div>
  `,
  styles: [`
    .app-container {
      min-height: 100vh;
      background: #f5f5f5;
    }
    .app-header {
      background: #007bff;
      color: white;
      padding: 1rem;
      text-align: center;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .app-content {
      max-width: 1200px;
      margin: 0 auto;
      padding: 2rem;
    }
    .upload-section {
      max-width: 600px;
      margin: 0 auto;
    }
    .results-section {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 2rem;
    }
    @media (max-width: 768px) {
      .results-section {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class AppComponent {
  currentAudioId: string = '';

  onFileUploaded(audioId: string) {
    this.currentAudioId = audioId;
  }
}
