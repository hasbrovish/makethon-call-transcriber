import { Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { CallDetailsComponent } from './components/call-details/call-details.component';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'call/:id', component: CallDetailsComponent },
  { path: '**', redirectTo: '' }
];
